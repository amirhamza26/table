(function ($) {
    "use strict";

    // slider - active
    $('.slider-active').slick({
        dots: true,
        arrows: true,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: false,
        autoplayTimeout:1000,
        responsive: [
          {
            breakpoint: 1050,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              infinite: true,
              dots: true,
              arrows:false
            }
          },
          {
            breakpoint: 576,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1
            }
          }
        ]
      }); 

    
    // brand-active
    $('.brand-active').slick({
        dots: false,
        arrows:false,
        infinite: true,
        speed: 1000,
        slidesToShow: 5,
        slidesToScroll: 2,
        autoplay: true,
        autoplayTimeout:1000,
        responsive: [
          {
            breakpoint: 1050,
            settings: {
              slidesToShow: 5,
              slidesToScroll: 2,
              infinite: true,
              dots: true
            }
          },
          {
            breakpoint: 780,
            settings: {
              slidesToShow: 4,
              slidesToScroll: 2
            }
          },
          {
            breakpoint: 576,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1
            }
          }
          // You can unslick at a given breakpoint now by adding:
          // settings: "unslick"
          // instead of a settings object
        ]
      }); 

    // counterUp
    $('.counter').counterUp({
        delay: 10,
        time: 1000
    });


})(jQuery);	    

function sentbuton(){
    document.getElementById('changetext').innerHTML='Text Delivered'
    document.getElementById('changetext').style.color= '#f5a51c'
    document.getElementById('changetext').style.background= '#05243e'
}