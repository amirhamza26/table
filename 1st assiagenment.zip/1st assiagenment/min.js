function sentbuton(){
    document.getElementById('changetext').innerHTML='Text Delivered'
    document.getElementById('changetext').style.color= 'yellowgreen'
    document.getElementById('changetext').style.background= '#474d6b'
}
